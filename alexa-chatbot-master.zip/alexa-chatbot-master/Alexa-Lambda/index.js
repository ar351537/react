/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/

const Alexa = require('alexa-sdk');
const request = require('superagent');
const co = require('co');
const config = require('config');
const mongoose = require('mongoose');
const sgMail = require('@sendgrid/mail');

const HELP_MESSAGE = 'I can help you find interaction between Diabetic and Ashtma drugs.';
const HELP_REPROMPT = 'What can I help you with?';
const NAME_CHECK_URL = 'https://www.medscape.com/api/quickreflookup/LookupService.ashx?q=';
const INTERACTION_CHECK_URL = 'https://reference.medscape.com/druginteraction.do?action=getMultiInteraction&ids=';

let speechOutput;
let conn = null;
let logData;

function recordHealthStatus(logData) {
  return co(function*() {
    // Because `conn` is in the global scope, Lambda may retain it between
    // function calls thanks to `callbackWaitsForEmptyEventLoop`.
    // This means your Lambda function doesn't have to go through the
    // potentially expensive process of connecting to MongoDB every time.
    if (conn == null) {
      conn = yield mongoose.createConnection(config.db.url);
      conn.model('HealthRecords', new mongoose.Schema({ 
        name: String, 
        interaction_time: { type: Date, default: Date.now },
        drugs: String,
        interactions: String,
        notes: String
      }));
    }
    const model = conn.model('HealthRecords');
    yield model.insertMany([ logData ]);
    return true;
  });
}


/**
 * send email to user
 * @param email the email entity ,  {to:,subject:,text:,html:}
 * @returns {Promise}
 */
function sendEmail(emailEntity) {
  return co(function*() {
    sgMail.setApiKey(config.SENDGRID_API_KEY);
    yield sgMail.send(emailEntity);
    return true;
  });
}

const handlers = {
    'LaunchRequest': function () {
        this.emit('WelcomeMessage');
    },
    'SessionEndedRequest': function () {
        this.response.speak('Bye. Have a nice day');
        this.emit(':responseReady');
    },
    'DrugInteractionCheck': function () {
      if (this.event.request.intent.slots.diabeticTablet.value && 
            this.event.request.intent.slots.asthmaTablet.value) {
        if (this.event.request.intent.slots.diabeticTablet.resolutions.resolutionsPerAuthority[0].status.code === 'ER_SUCCESS_MATCH' 
        && this.event.request.intent.slots.asthmaTablet.resolutions.resolutionsPerAuthority[0].status.code === 'ER_SUCCESS_MATCH') {
          request
        .get(NAME_CHECK_URL + this.event.request.intent.slots.diabeticTablet.resolutions.resolutionsPerAuthority[0].values[0].value.name)
        .end((err, res) => {
            const diabeticId = res.body.types[0].references[0].id;
            request
              .get(NAME_CHECK_URL + this.event.request.intent.slots.asthmaTablet.resolutions.resolutionsPerAuthority[0].values[0].value.name)
              .end((err, res) => {
                  const asthmaId = res.body.types[0].references[0].id;
                  request
                    .get(INTERACTION_CHECK_URL + diabeticId + ',' + asthmaId)
                    .end((err, res) => {
                      const response = JSON.parse(res.text)
                      if (response.errorCode === 0) {
                        speechOutput = 'You are Safe!! There are no problems using these drugs together';
                        this.attributes['intent_name'] = 'safe';
                        logData = {
                          name: 'John',
                          drugs: this.event.request.intent.slots.diabeticTablet.resolutions.resolutionsPerAuthority[0].values[0].value.name +
                          ' and ' + this.event.request.intent.slots.asthmaTablet.resolutions.resolutionsPerAuthority[0].values[0].value.name,
                          interactions: 'No',
                          notes: 'No interactions found'
                          };
                        } else {
                        speechOutput = 'Oops! There are problems. ' + 
                        response.multiInteractions[0].text + ' Would you like me to update your personal health record about this, and send a note to your doctor?';
                        this.attributes['intent_name'] = this.event.request.intent.name;
                        logData = {
                          name: 'John',
                          drugs: this.event.request.intent.slots.diabeticTablet.resolutions.resolutionsPerAuthority[0].values[0].value.name +
                          ' and ' + this.event.request.intent.slots.asthmaTablet.resolutions.resolutionsPerAuthority[0].values[0].value.name,
                          interactions: 'Yes',
                          notes: response.multiInteractions[0].text
                        };
                      }
                      recordHealthStatus(logData).
                          then(res => {
                            this.emit(':ask', speechOutput);
                          }).
                          catch(error => {
                            console.log("Error: ");
                            console.log(error);
                          });
                  });
              });
         });
        } else {
          this.emit(':delegate');
        }
      }
      else {
        this.emit(':delegate');
      }
        
    },
    'WelcomeMessage': function () {
        speechOutput = 'Hey, Good Morning. How are you doing Today?';
        this.emit(':ask', speechOutput);
    },
    'FeelingWell': function () {
        speechOutput = 'Cool. Are you taking your medicines regularly?';
        this.attributes['intent_name'] = this.event.request.intent.name;
        this.emit(':ask', speechOutput);
    },
    'UserConsent': function () {
        let speak = true;
        if( this.attributes['intent_name'] === 'FeelingWell' && this.event.request.intent.slots.consent.resolutions.resolutionsPerAuthority[0].values[0].value.name === 'Yes') {
          speechOutput = 'Good to know. Which medicines did you take yesterday night?';
        } else if( this.attributes['intent_name'] === 'FeelingWell' && this.event.request.intent.slots.consent.resolutions.resolutionsPerAuthority[0].values[0].value.name === 'No') {
          speak = false;
          logData = {
            name: 'John',
            drugs: 'None',
            interactions: 'No',
            notes: 'John not following medication'
            };
          speechOutput = 'Are you facing any difficulties in following Medication?';
          this.attributes['intent_name'] = 'FollowingMedicine';
          recordHealthStatus(logData).
            then(res => {
              this.emit(':ask', speechOutput);
            }).
            catch(error => {
              console.log("Error: ");
              console.log(error);
            });
        } else if( this.attributes['intent_name'] === 'DrugInteractionCheck' && this.event.request.intent.slots.consent.resolutions.resolutionsPerAuthority[0].values[0].value.name === 'Yes') {
          speak = false;
          const mailOptions = {
              to: config.TO_EMAIL.split(","),
              from: config.FROM_EMAIL,
              subject: 'Your Patient John Health is Critical',
              text: 'Please check John Health records immediately and advise him', // plain text body
              html: 'Dear Doctor,<br><br>Please check John Health records immediately and advise him.<br><br>Thanks,<br>Alexa' // html body
          };
          speechOutput = 'I have sent a note to your Doctor. Take care of your health. Famous proverb says Health is wealth';
          this.attributes['intent_name'] = 'close';
          sendEmail(mailOptions).
          then(res => {
              this.emit(':ask', speechOutput);
            }).
            catch(error => {
              console.log("Error: ");
              console.log(error);
            });
        } else if( this.attributes['intent_name'] === 'DrugInteractionCheck' && this.event.request.intent.slots.consent.resolutions.resolutionsPerAuthority[0].values[0].value.name === 'No') {
          speechOutput = 'Take care of your health. Famous proverb says Health is wealth';
          this.attributes['intent_name'] = 'close';
        } else if( this.attributes['intent_name'] === 'FollowingMedicine') {
          speechOutput = 'Do you want me to fix up an appointment with your doctor to discuss further?';
          this.attributes['intent_name'] = 'Appointment';
        } else if( this.attributes['intent_name'] === 'Appointment' && this.event.request.intent.slots.consent.resolutions.resolutionsPerAuthority[0].values[0].value.name === 'Yes') {
          speak = false;
          const mailOptions = {
              to: config.TO_EMAIL.split(","),
              from: config.FROM_EMAIL,
              subject: 'Appointment required for Patient John',
              text: 'Your patient John would like to fix an appointment for consultation. Please confirm a slot and let him know', // plain text body
              html: 'Dear Doctor,<br><br>Your patient John would like to fix an appointment for consultation. <br><br>Please confirm a slot and let him know.<br><br>Thanks,<br>Alexa' // html body
          };
          speechOutput = 'I have sent a note to your Doctor. Take care of your health. Famous proverb says Health is wealth';
          this.attributes['intent_name'] = 'close';
          sendEmail(mailOptions).
          then(res => {
              this.emit(':ask', speechOutput);
            }).
            catch(error => {
              console.log("Error: ");
              console.log(error);
            });
        } else if( this.attributes['intent_name'] === 'Appointment' && this.event.request.intent.slots.consent.resolutions.resolutionsPerAuthority[0].values[0].value.name === 'No') {
          speechOutput = 'Take care of your health. Famous proverb says Health is wealth';
          this.attributes['intent_name'] = 'close';
        } else if( this.attributes['intent_name'] === 'safe') {
          speechOutput = 'Famous proverb says Health is wealth. Have a Nice day.';
          this.emit(':tell', speechOutput);
        } else if( this.attributes['intent_name'] === 'close') {
          speechOutput = 'Bye. Have a Nice day.';
          this.emit(':tell', speechOutput);
        }
        if (speak) {
          this.emit(':ask', speechOutput);
        }
    },
    'Thankful': function() {
      if (this.attributes['intent_name'] === 'Appointment' || this.attributes['intent_name'] === 'DrugInteractionCheck' || this.attributes['intent_name'] === 'safe' || this.attributes['intent_name'] === 'close') {
        this.emit(':tell', 'You are Welcome.  Have a great day');
      } else {
        this.emit(':ask', 'You are Welcome.');
      }
    },
    'NotFeelingWell': function () {
        speechOutput = 'Sorry to hear that. Which medicines did you take Yesterday night?';
        this.attributes['intent_name'] = this.event.request.intent.name;
        this.emit(':ask', speechOutput);
    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = HELP_MESSAGE;
        const reprompt = HELP_REPROMPT;
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak('Bye. Have a nice day');
        this.emit(':responseReady');
    },
};

exports.handler = function (event, context, callback) {
    context.callbackWaitsForEmptyEventLoop = false;
    const alexa = Alexa.handler(event, context, callback);
    alexa.registerHandlers(handlers);
    alexa.execute();
};
