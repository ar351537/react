# Lambda for Alexa

Objective of this Lambda is to support Alexa skill `Drug checker`

## Functionalities

1. Handle User conversation

2. Lookup https://reference.medscape.com/drug-interactionchecker for the potential interactions of drugs and let the user know the same

3. Record the drug interactions in Mongo DB

4. Trigger email to Doctor when user consents to set an appointment with doctor (Using Sendgrid)

### Environment variables

Following environment variables need to be set in Lambda Console

1. MONGOLAB_URI - Remote Mongo Database URI

2. SENDGRID_API_KEY - Sendgrid API key used for sending emails

3. FROM_EMAIL - From email to be used when the email is triggered to Doctor

4. TO_EMAIL - Comma separated string of Email ID's to which email need to be sent (Assuming they are Docctors)

### Deploying in Lambda

1. Zip all the files including `node_modules` and upload to Lambda

2. All files should be at root directory in the zip file. No encapsulation like `Lambda/index.js` instead `index.js` should be available at root directory.

2. Please note node_modules directory is mandatory since Lambda will not run `npm install`