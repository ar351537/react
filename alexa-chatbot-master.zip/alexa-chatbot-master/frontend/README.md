# Medical Reporter Sample

Application deployed at - https://medicalreports.herokuapp.com

UI is very simple and there will be only one tab

1. You will be able to look at the Patient health records

2. Filter by Patient Name, interactions, etc..

3. Delete all records from the database


## Username and password

All users have password `123456`

Valid Usernames

1. doctor
2. admin

## Local Deployment steps

#### Pre-requisites

1. Web server which supports PHP like Apache, IIS, etc..

#### Steps

1. Website is built using PHP

2. Simply unzip the website content to any web server like Apache, XAMPP, etc..

3. Web server will take care of serving the website

## Heroku deployment steps

#### Pre-requisites

1. Heroku CLI installed in the system

#### Steps

1. Login into Heroku using CLI

```
heroku login
```

2. Create a new heroku application 

To assign any random name to your application use the below command

```
heroku create
```

If application need to be created with your favorite name, use the below command

```
heroku apps:create <app_name>
```

3. Push to heroku for deployment

```
git push heroku master
```
