<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

class User extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Medical Reports';

        $searchText = $this->security->xss_clean($this->input->post('searchText'));
        $data['searchText'] = $searchText;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->config->item('backend_url') . '/healthrecords/search?generic=' . $searchText);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Authorization: Bearer '. $this->token
        ));

        $result = json_decode(curl_exec($ch));
        
        curl_close($ch);

        $data['healthrecords'] = $result->healthrecords;
        
        $this->loadViews("healthrecords", $this->global, $data, NULL);
    }

    /**
     * This function used to load the first screen of the user
     */
    public function deleteAll()
    {
 
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->config->item('backend_url') . '/deleteAll');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Authorization: Bearer '. $this->token
        ));

        $result = json_decode(curl_exec($ch));
        
        curl_close($ch);

        redirect('/reports');
    }

    /**
     * Page not found : error 404
     */
    function pageNotFound()
    {
        $this->global['pageTitle'] = 'Topcoder : 404 - Page Not Found';
        
        $this->loadViews("404", $this->global, NULL, NULL);
    }

    
}

?>