<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-dashboard"></i> Patient Health Records
      </h1>
    </section>
    <section class="content">
      <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>deleteAll">Delete All</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Health Records</h3>
                    <div class="box-tools">
                        <form action="<?php echo base_url() ?>reports" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table class="table table-hover">
                    <tr>
                     <th>Patient Name</th>
                      <th>Recorded Time</th>
                      <th>Interactions</th>
                      <th>Drugs</th>
                      <th class="col-md-5">Notes</th>
                    </tr>
                    <?php
                    if(!empty($healthrecords))
                    {
                        foreach($healthrecords as $record)
                        {
                    ?>
                    <tr>
                      <td><?php echo $record->name ?></td>
                      <td><?php echo $record->interaction_time ?></td>
                      <td><?php echo $record->interactions ?></td>
                      <td><?php echo $record->drugs ?></td>
                      <td><?php echo $record->notes ?></td>
                    </tr>
                    <?php
                        }
                    }
                    ?>
                  </table>
                  
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
