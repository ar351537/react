# Medical Reporter API

Application deployed at - https://medicalreportsapi.herokuapp.com/api/v1

Objective of this API is support to the front end used for viewing Patient health records deployed at https://medicalreports.herokuapp.com

## Local deployment steps

#### Pre-requisites

1. Node.js 8.10.x

2. Npm 5.6.x

3. Local Mongo DB or MLAB Account

#### Steps

1. Install all dependencies

```
npm i
```

2. Change configuration variables if necessary in `config/default.js`

3. Run the API

```
npm start
```


4. Run in Development mode

```
npm run dev
```


## Heroku deployment steps

#### Pre-requisites

1. Heroku CLI installed in the system

#### Steps

1. Login into Heroku using CLI

```
heroku login
```

2. Create a new heroku application 

To assign any random name to your application use the below command

```
heroku create
```

If application need to be created with your favorite name, use the below command

```
heroku apps:create <app_name>
```

3. Push to heroku for deployment

```
git push heroku master
```

## Testing and Verification

1. Import postman collection from `docs` directory and start testing by triggering requests.

2. First step would be to login and then you could start testing other end points.

**Environment variable API_URL is currently pointing to `https://medicalreportsapi.herokuapp.com/api/v1`**. Please update if required
