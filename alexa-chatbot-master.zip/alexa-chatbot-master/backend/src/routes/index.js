/**
 * Defines the API routes
 */

const _ = require('lodash');
const LoginRoutes = require('./LoginRoutes');
const HealthrecordsRoutes = require('./HealthrecordsRoutes');

module.exports = _.extend({}, LoginRoutes, HealthrecordsRoutes);
