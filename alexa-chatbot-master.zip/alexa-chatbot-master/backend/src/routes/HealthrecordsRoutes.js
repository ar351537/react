/*
 * Define Healthrecords related end points
 */

const auth = require('../common/Auth.js');

module.exports = {
  '/healthrecords/search': {
    get: {
      controller: 'HealthrecordsController',
      method: 'searchHealthRecords',
      middleware: [auth()],
    },
  },
  '/healthrecords': {
    get: {
      controller: 'HealthrecordsController',
      method: 'getHealthRecords',
      middleware: [auth()],
    },
  },
  '/deleteAll': {
    post: {
      controller: 'HealthrecordsController',
      method: 'deleteAllRecords',
      middleware: [auth()],
    },
  },
};
