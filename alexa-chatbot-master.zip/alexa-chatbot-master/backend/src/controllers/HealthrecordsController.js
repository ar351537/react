/*
 * Define Health records controller
 */

const HealthrecordsService = require('../services/HealthrecordsService');

/**
 * Search Health records in database
 * @param req the request
 * @param res the response
 */
function* searchHealthRecords(req, res) {
  res.json(yield HealthrecordsService.searchHealthRecords(req.query));
}

/**
 * Get health records of all patients
 * @param req the request
 * @param res the response
 */
function* getHealthRecords(req, res) {
  res.json(yield HealthrecordsService.getHealthRecords());
}

/**
 * Delete health records of all patients
 * @param req the request
 * @param res the response
 */
function* deleteAllRecords(req, res) {
  res.json(yield HealthrecordsService.deleteAllRecords());
}

module.exports = {
  searchHealthRecords,
  getHealthRecords,
  deleteAllRecords,
};
