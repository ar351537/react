/**
 * Init models
 */

const config = require('config');
const db = require('../datasource').getDb(config.db.url, config.db.poolSize);
const { UserSchema } = require('./User');
const { HealthrecordSchema } = require('./Healthrecords');

module.exports = {
  User: db.model('User', UserSchema),
  Healthrecords: db.model('Healthrecords', HealthrecordSchema),
  db,
};
