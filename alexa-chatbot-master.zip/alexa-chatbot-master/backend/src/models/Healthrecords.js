/**
 * the Health Record schema
 */

const Schema = require('mongoose').Schema;

const HealthrecordSchema =  new Schema({ 
  name: String, 
  interaction_time: { type: Date, default: Date.now },
  drugs: String,
  interactions: String,
  notes: String
});

module.exports = {
  HealthrecordSchema,
};
