/**
 * Login service to aid in login
 */

const models = require('../models');
const crypto = require('crypto');
const joi = require('joi');
const errors = require('common-errors');
const _ = require('lodash');
const jwt = require('jsonwebtoken');
const config = require('config');
const httpStatus = require('http-status');

/**
 * use md5 hash password
 * @param password
 * @return {Buffer | string}
 */
function generateHash(password) {
  const md5sum = crypto.createHash('md5');
  md5sum.update(password);
  return md5sum.digest('hex');
}

/**
 * Generate a jwt token for specified user
 * @param  {Object}     userObj     the user for which to generate the token
 */
function generateToken(userObj) {
  const jwtBody = {
    username: userObj.username,
    userType: userObj.userType,
  };
  return jwt.sign(jwtBody, new Buffer(config.CLIENT_SECRET, 'base64'), {
    expiresIn: config.TOKEN_EXPIRES,
    audience: config.CLIENT_ID,
  });
}

/**
 * Function to login the User
 * If the player token is not generated already, register player
 * in Amazon Gameon and store the resulting token.
 * @param entity
 */
function* login(entity) {
  
  let user = yield models.User.findOne({ username: entity.username });
  // Check if the user with given user name exists
  if (!user) {
    throw new errors.HttpStatusError(httpStatus.UNAUTHORIZED, 'User name does not exist.');
  }

  const password = generateHash(entity.password);

  // Compare the hashed password
  if (user.password !== password) {
    throw new errors.HttpStatusError(httpStatus.UNAUTHORIZED, 'Invalid Credentials.');
  }

  // Generate JWT Token for Application login
  const result = { token: generateToken(user) };

  // Return JWT
  return result;
}

login.schema = {
  entity: joi.object().keys({
    username: joi.string().required(),
    password: joi.string().required(),
  }).required(),
};

module.exports = {
  login,
};
