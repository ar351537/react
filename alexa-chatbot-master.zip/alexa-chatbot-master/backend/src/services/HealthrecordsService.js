/*
 * Health records service Implementation
 */

const models = require('../models');
const co = require('co');
const joi = require('joi');
const _ = require('lodash');
const errors = require('common-errors');
const helper = require('../common/helper');
const Op = require('mongoose').Op; // eslint-disable-line

/**
 * Search Health records in database
 * @param filter the rate query filter
 * @return {{items: Array}}
 */
function* searchHealthRecords(filter) {
  let query = {}
  if (filter.name) query = _.extend(query, { name: new RegExp(filter.name, 'i') });
  if (filter.drugs) query = _.extend(query, { drugs: new RegExp(filter.drugs, 'i') });
  if (filter.interactions) query = _.extend(query, { interactions: new RegExp(filter.interactions, 'i') });
  if (filter.notes) query = _.extend(query, { notes: new RegExp(filter.notes, 'i') });
  if (filter.generic) query = { $or: [ { name: new RegExp(filter.generic, 'i') }, 
    { drugs: new RegExp(filter.generic, 'i') }, { interactions: new RegExp(filter.generic, 'i') }, 
    { notes: new RegExp(filter.generic, 'i') } ] };
  const result = yield models.Healthrecords.find(query).select('-_id -__v');
  const healthrecords = _.map(result, r => r);
  return {
    healthrecords,
  };
}

/**
 * Get health records of all patients
 */
function* getHealthRecords() {
  const result = yield models.Healthrecords.find({}).select('-_id -__v');
  return { "healthrecords": result };
}

/**
 * Delete all records
 */
function* deleteAllRecords() {
  yield models.Healthrecords.remove({});
  return true;
}

module.exports = {
  searchHealthRecords,
  getHealthRecords,
  deleteAllRecords,
};
