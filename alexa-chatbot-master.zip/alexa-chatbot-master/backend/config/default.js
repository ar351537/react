/**
 * Default configuration file
 */

module.exports = {
  LOG_LEVEL: process.env.LOG_LEVEL || 'debug',
  WEB_SERVER_PORT: process.env.PORT || 3000,
  CLIENT_ID: process.env.CLIENT_ID || 'testing',
  CLIENT_SECRET: process.env.CLIENT_SECRET || 'mysecret',
  TOKEN_EXPIRES: 24 * 60 * 60 * 30, // 30 days
  API_VERSION: 'api/v1',
  DEFAULT_MESSAGE: 'Internal Server Error',
  db: {
    url: process.env.MONGOLAB_URI || 'mongodb://root:admin@ds263759.mlab.com:63759/interactions',
    poolSize: 5,
  }
};
