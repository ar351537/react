var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var mongodbase = require('./routes/alexa');
var index = require('./routes/index');
var app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use('/', express.static(path.join(__dirname, './webclient/')));

//Routes
app.use('/', index);
app.use('/anthem', mongodbase);

//Mongoose
var db = 'mongodb://admin:admin@ds241039.mlab.com:41039/anthemalexa';
mongoose.connect(db);

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
    console.log("connnected with mongo");
});

//Listening to port 3000
app.listen(process.env.PORT || 3000, '0.0.0.0', function(err, result) {
    if (err) {
        console.error("Error ", err);
    }
    console.log("Server started at 3000 or heroku");
});
