const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const user = new Schema({
    userId: String,
    sessionId: String,   
    name: String,
    deviceID:String,
     });

const userinfo = mongoose.model('userdetails', user);
module.exports = userinfo;
