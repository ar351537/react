var express = require('express');
var router = express.Router();
const user = require('../models/user');

router.get('/getUser', function(req, res, next) {
  user.find({}, function(err, out) {
    if(err) {
      res.status(500).send('Error in readuser');
    }
    else{
      res.json(out);
    }
  });
});

router.post('/setUser', function(req, res, next) {
  var userdetail = new user({
    userId: req.body.userId,
    sessionId: req.body.sessionId,   
    name: req.body.name,
    deviceID:req.body.deviceID,
  });
userdetail.save(function (err,out) {
  if (err) {
    return err;
  }
  else {
res.json(out);
  }
});
});




module.exports = router;
